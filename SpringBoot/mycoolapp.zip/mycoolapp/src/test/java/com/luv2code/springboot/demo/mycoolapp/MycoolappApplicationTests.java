package com.luv2code.springboot.demo.mycoolapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MycoolappApplicationTests {

	@Test
	void contextLoads() {
	}

}
